﻿using Domain.Entities.Base;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public sealed class Transaction : BaseEntity
    {
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
        public TransactionType Type { get; set; } // "Income" or "Expense"
        public Category Category { get; set; }
        public Account Account { get; set; }

        public Guid CategoryId { get; set; }
        public Guid AccountId { get; set; }



    }

    public enum TransactionType
    {
        Income,
        Expense
    }

}
