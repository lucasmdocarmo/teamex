﻿namespace API.Controllers
{
    using Asp.Versioning;
    using Domain.Entities;
    using Infrastructure;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Threading.Tasks;

    [ApiVersion("1.0")]
    [Route("api/v{api-version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    [AllowAnonymous]
    public class AccountsController(IFinanceRepository repository) : ControllerBase
    {
        private readonly IFinanceRepository _repository = repository;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _repository.GetAllAccountsAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var account = await _repository.GetAccountByIdAsync(id);
            if (account == null) return NotFound();
            return Ok(account);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Account account)
        {
            await _repository.AddAccountAsync(account);
            return CreatedAtAction(nameof(Get), new { id = account.Id }, account);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] Account account)
        {
            if (id != account.Id) return BadRequest("Account ID mismatch");

            var existingAccount = await _repository.GetAccountByIdAsync(id);
            if (existingAccount == null) return NotFound();

            await _repository.UpdateAccountAsync(account);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _repository.DeleteAccountAsync(id);
            return NoContent();
        }
    }
}