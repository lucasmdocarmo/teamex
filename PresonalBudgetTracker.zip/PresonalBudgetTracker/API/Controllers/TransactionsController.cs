﻿namespace API.Controllers
{
    using Asp.Versioning;
    using Domain.Entities;
    using Infrastructure;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Threading.Tasks;


    [ApiVersion("1.0")]
    [Route("api/v{api-version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    [AllowAnonymous]
    public class TransactionsController(ITransactionRepository repository) : ControllerBase
    {
        private readonly ITransactionRepository _repository = repository;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _repository.GetAllTransactionsAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var transaction = await _repository.GetTransactionByIdAsync(id);
            if (transaction == null) return NotFound();
            return Ok(transaction);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Transaction transaction)
        {
            await _repository.AddTransactionAsync(transaction);
            return CreatedAtAction(nameof(Get), new { id = transaction.Id }, transaction);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] Transaction transaction)
        {
            if (id != transaction.Id) return BadRequest("Transaction ID mismatch");

            var existingTransaction = await _repository.GetTransactionByIdAsync(id);
            if (existingTransaction == null) return NotFound();

            await _repository.UpdateTransactionAsync(transaction);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _repository.DeleteTransactionAsync(id);
            return NoContent();
        }

        [HttpGet("filter")]
        public async Task<IActionResult> Filter([FromQuery] string type, [FromQuery] string category, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
        {
            return Ok(await _repository.GetTransactionsByFilterAsync(type, category, startDate, endDate));
        }
    }
}
