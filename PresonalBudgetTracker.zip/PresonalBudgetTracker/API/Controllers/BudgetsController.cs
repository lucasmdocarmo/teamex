﻿using Asp.Versioning;
using Domain.Entities;
using Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{

    [ApiVersion("1.0")]
    [Route("api/v{api-version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    [AllowAnonymous]
    public class BudgetsController(IFinanceRepository repository) : ControllerBase
    {
        private readonly IFinanceRepository _repository = repository;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _repository.GetAllBudgetsAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var budget = await _repository.GetBudgetByIdAsync(id);
            if (budget == null) return NotFound();
            return Ok(budget);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Budget budget)
        {
            await _repository.AddBudgetAsync(budget);
            return CreatedAtAction(nameof(Get), new { id = budget.Id }, budget);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] Budget budget)
        {
            if (id != budget.Id) return BadRequest("Budget ID mismatch");

            var existingBudget = await _repository.GetBudgetByIdAsync(id);
            if (existingBudget == null) return NotFound();

            await _repository.UpdateBudgetAsync(budget);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _repository.DeleteBudgetAsync(id);
            return NoContent();
        }
    }
}
