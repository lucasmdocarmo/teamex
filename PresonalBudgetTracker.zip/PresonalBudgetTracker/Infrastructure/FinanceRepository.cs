﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public interface IFinanceRepository
    {
        // Transaction methods
        Task<List<Transaction>> GetAllTransactionsAsync();
        Task<Transaction> GetTransactionByIdAsync(Guid id);
        Task UpdateTransactionAsync(Transaction transaction);
        Task DeleteTransactionAsync(Guid id);
        Task<List<Transaction>> GetTransactionsByAccountAsync(Guid accountId);

        // Account methods
        Task<List<Account>> GetAllAccountsAsync();
        Task<Account> GetAccountByIdAsync(Guid id);
        Task UpdateAccountAsync(Account account);
        Task DeleteAccountAsync(Guid id);
        Task AddAccountAsync(Account account);
        decimal GetAccountBalance(Guid accountId);

        // Category methods
        Task<List<Category>> GetAllCategoriesAsync();
        Task AddCategoryAsync(Category category);
        Task<Category> GetCategoryByIdAsync(Guid id);
        Task UpdateCategoryAsync(Category category);
        Task DeleteCategoryAsync(Guid id);

        // Budget methods
        Task<List<Budget>> GetAllBudgetsAsync();
        Task AddBudgetAsync(Budget budget);
        Task<Budget> GetBudgetByIdAsync(Guid id);
        Task UpdateBudgetAsync(Budget budget);
        Task DeleteBudgetAsync(Guid id);
        Task<decimal> CheckBudgetStatusAsync(Guid budgetId);
    }
    public class FinanceRepository(BudgetTrackerContext context): IFinanceRepository
    {
        private readonly BudgetTrackerContext _context = context;

        // Transaction methods
        public async Task<List<Transaction>> GetAllTransactionsAsync()
        {
            return await _context.Transactions.Include(t => t.Category).Include(t => t.Account).ToListAsync();
        }
        public async Task<Transaction> GetTransactionByIdAsync(Guid id)
        {
            return await _context.Transactions.Include(t => t.Category).Include(t => t.Account).FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task UpdateTransactionAsync(Transaction transaction)
        {
            _context.Transactions.Update(transaction);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransactionAsync(Guid id)
        {
            var transaction = await GetTransactionByIdAsync(id);
            if (transaction != null)
            {
                _context.Transactions.Remove(transaction);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Transaction>> GetTransactionsByAccountAsync(Guid accountId)
        {
            return await _context.Transactions.Where(t => t.Account.Id == accountId).ToListAsync();
        }

        // Account methods
        public async Task<List<Account>> GetAllAccountsAsync()
        {
            return await _context.Accounts.ToListAsync();
        }

        public async Task<Account> GetAccountByIdAsync(Guid id)
        {
            return await _context.Accounts.FindAsync(id);
        }

        public async Task UpdateAccountAsync(Account account)
        {
            _context.Accounts.Update(account);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAccountAsync(Guid id)
        {
            var account = await GetAccountByIdAsync(id);
            if (account != null)
            {
                _context.Accounts.Remove(account);
                await _context.SaveChangesAsync();
            }
        }
        public decimal GetAccountBalance(Guid accountId)
        {
            var transactions = _context.Transactions.Where(t => t.Account.Id == accountId).ToList();
            return transactions.Sum(t => t.Type == TransactionType.Income ? t.Amount : -t.Amount);
        }
        public async Task AddAccountAsync(Account account)
        {
            _context.Accounts.Add(account);
            await _context.SaveChangesAsync();
        }

        // Category methods
        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            return await _context.Categories.ToListAsync();
        }

        public async Task AddCategoryAsync(Category category)
        {
            _context.Categories.Add(category);
            await _context.SaveChangesAsync();
        }
        public async Task<Category> GetCategoryByIdAsync(Guid id)
        {
            return await _context.Categories.FindAsync(id);
        }

        public async Task UpdateCategoryAsync(Category category)
        {
            _context.Categories.Update(category);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteCategoryAsync(Guid id)
        {
            var category = await GetCategoryByIdAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();
            }
        }

        // Budget methods
        public async Task<List<Budget>> GetAllBudgetsAsync()
        {
            return await _context.Budgets.Include(b => b.Category).ToListAsync();
        }

        public async Task AddBudgetAsync(Budget budget)
        {
            _context.Budgets.Add(budget);
            await _context.SaveChangesAsync();
        }
        public async Task<Budget> GetBudgetByIdAsync(Guid id)
        {
            return await _context.Budgets.Include(b => b.Category).FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task UpdateBudgetAsync(Budget budget)
        {
            _context.Budgets.Update(budget);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteBudgetAsync(Guid id)
        {
            var budget = await GetBudgetByIdAsync(id);
            if (budget != null)
            {
                _context.Budgets.Remove(budget);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<decimal> CheckBudgetStatusAsync(Guid budgetId)
        {
            var budget = await GetBudgetByIdAsync(budgetId);
            var transactions = await _context.Transactions
                .Where(t => t.Category.Id == budget.Category.Id && t.Date.Month == DateTime.Now.Month)
                .ToListAsync();

            var spentAmount = transactions.Sum(t => t.Type == TransactionType.Expense ? t.Amount : 0);
            return budget.TargetAmount - spentAmount;
        }
    }
}
