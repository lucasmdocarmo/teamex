﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public interface ITransactionRepository
    {
        Task<List<Transaction>> GetAllTransactionsAsync();
        Task<Transaction> GetTransactionByIdAsync(Guid id);
        Task AddTransactionAsync(Transaction transaction);
        Task UpdateTransactionAsync(Transaction transaction);
        Task DeleteTransactionAsync(Guid id);
        Task<List<Transaction>> GetTransactionsByFilterAsync(string type, string category, DateTime? startDate, DateTime? endDate);
    }
    public class TransactionRepository(BudgetTrackerContext context): ITransactionRepository
    {
        private readonly BudgetTrackerContext _context = context;

        public async Task<List<Transaction>> GetAllTransactionsAsync()
        {
            return await _context.Transactions.ToListAsync();
        }

        public async Task AddTransactionAsync(Transaction transaction)
        {
            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();
        }

        public async Task<Transaction> GetTransactionByIdAsync(Guid id)
        {
            return await _context.Transactions.FindAsync(id);
        }

        public async Task UpdateTransactionAsync(Transaction transaction)
        {
            _context.Entry(transaction).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransactionAsync(Guid id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction != null)
            {
                _context.Transactions.Remove(transaction);
                await _context.SaveChangesAsync();
            }
        }
        // Enhanced filtering method
        public async Task<List<Transaction>> GetTransactionsByFilterAsync(string type, string category, DateTime? startDate, DateTime? endDate)
        {
            IQueryable<Transaction> query = _context.Transactions;

            if (!string.IsNullOrWhiteSpace(type))
            {
                if (Enum.TryParse<TransactionType>(type, true, out var transactionType))
                {
                    query = query.Where(t => t.Type == transactionType);
                }
            }

            if (!string.IsNullOrWhiteSpace(category))
            {
                var categoryObj = await _context.Categories.FirstOrDefaultAsync(c => c.Name == category);
                if (categoryObj != null)
                {
                    query = query.Where(t => t.Category.Id == categoryObj.Id);
                }
            }

            if (startDate.HasValue && endDate.HasValue)
            {
                query = query.Where(t => t.Date >= startDate.Value && t.Date <= endDate.Value);
            }

            return await query.ToListAsync();
        }
    }
}
